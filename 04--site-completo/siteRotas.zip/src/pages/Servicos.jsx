const Servicos = () => {
    return <h1>Nossos Serviços</h1>;
};

export default Servicos;
