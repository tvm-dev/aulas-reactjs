const Contato = () => {
    return <h1>Fale Conosco</h1>;
};

export default Contato;
