const Inicio = () => {
    return <h1>Página Inicial</h1>;
};

export default Inicio;
